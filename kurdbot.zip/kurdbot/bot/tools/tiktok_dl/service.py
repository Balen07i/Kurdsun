from __future__ import annotations

import logging
import re
import uuid
from dataclasses import dataclass

import yt_dlp

from bot.core.config import settings

logger = logging.getLogger(__name__)

_TIKTOK_URL_RE = re.compile(r"https?://(www\.|vm\.|vt\.)?tiktok\.com/\S+", re.IGNORECASE)


@dataclass
class DownloadResult:
    success: bool
    file_path: str | None = None
    error: str | None = None


def is_valid_tiktok_url(text: str) -> bool:
    return bool(_TIKTOK_URL_RE.search(text.strip()))


def download_tiktok(url: str) -> DownloadResult:
    """Downloads a TikTok video (no watermark where yt-dlp supports it) to a temp file."""
    out_path = f"{settings.tmp_dir}/tiktok_{uuid.uuid4().hex}.mp4"

    ydl_opts = {
        "outtmpl": out_path,
        "format": "mp4/best",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "max_filesize": 50 * 1024 * 1024,  # Telegram bot API limit for uploads
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        return DownloadResult(success=True, file_path=out_path)
    except Exception as exc:
        logger.warning("TikTok download failed for url=%s: %s", url, exc)
        return DownloadResult(success=False, error=str(exc))
