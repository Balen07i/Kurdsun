import logging
import uuid

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from bot.core.config import settings
from bot.core.db.session import create_job, get_or_create_user, get_session
from bot.core.i18n.ku import t
from bot.core.keyboards.main_menu import cancel_keyboard
from bot.core.quota import has_quota_remaining

logger = logging.getLogger(__name__)

router = Router(name="ocr_image")

TOOL_ID = "ocr"


class OcrStates(StatesGroup):
    waiting_for_image = State()


@router.callback_query(F.data == f"tool:{TOOL_ID}")
async def start_ocr(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(OcrStates.waiting_for_image)
    await callback.message.edit_text(t("ocr_ask_image"), reply_markup=cancel_keyboard())
    await callback.answer()


@router.message(StateFilter(OcrStates.waiting_for_image), F.photo)
async def receive_image(message: Message, state: FSMContext) -> None:
    async with get_session() as session:
        user = await get_or_create_user(session, message.from_user.id, message.from_user.username)
        if not await has_quota_remaining(session, user, TOOL_ID):
            await message.answer(t("rate_limited", limit="N"))
            await state.clear()
            return

        job_id = str(uuid.uuid4())
        await create_job(session, job_id, user.id, message.chat.id, TOOL_ID)

    # Download the highest-resolution version of the photo to a temp file.
    photo = message.photo[-1]
    file = await message.bot.get_file(photo.file_id)
    local_path = f"{settings.tmp_dir}/ocr_{uuid.uuid4().hex}.jpg"
    await message.bot.download_file(file.file_path, destination=local_path)

    await state.clear()
    await message.answer(t("processing"))

    from bot.worker.tasks import process_ocr

    process_ocr.delay(job_id=job_id, chat_id=message.chat.id, user_id=user.id, image_path=local_path)
